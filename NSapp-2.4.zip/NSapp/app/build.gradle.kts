plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.samet.nsapp"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.samet.nsapp"
        minSdk = 24
        targetSdk = 35
        versionCode = 5
        versionName = "2.4"
    }

    // Sabit imza: Android Studio'da da GitHub'da da aynı anahtar kullanılır,
    // böylece yeni sürüm eskinin üstüne kurulur ve veriler silinmez.
    signingConfigs {
        create("ns") {
            storeFile = file("nsapp.keystore")
            storePassword = "nsapp2026"
            keyAlias = "nsapp"
            keyPassword = "nsapp2026"
        }
    }

    buildTypes {
        getByName("debug") {
            signingConfig = signingConfigs.getByName("ns")
        }
        getByName("release") {
            isMinifyEnabled = false
            signingConfig = signingConfigs.getByName("ns")
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
    }
}

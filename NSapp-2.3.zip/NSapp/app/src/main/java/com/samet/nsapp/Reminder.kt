package com.samet.nsapp

import android.app.AlarmManager
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Build
import org.json.JSONArray

/** Alarm çalınca hatırlatma bildirimini gösterir. */
class ReminderReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, intent: Intent) {
        try { Reminder.fire(c) } catch (_: Exception) {}
    }
}

/** Gece vardiyası hatırlatmaları: liste arayüzden gelir, sıradaki için alarm kurulur. */
object Reminder {
    private const val P = "ns_remind"
    private const val CH = "ns_vardiya"
    private const val NID = 21
    private const val LATE_MS = 6L * 60L * 60L * 1000L

    private fun sp(c: Context) = c.getSharedPreferences(P, Context.MODE_PRIVATE)

    private fun list(c: Context): JSONArray =
        try { JSONArray(sp(c).getString("list", "[]")) } catch (e: Exception) { JSONArray() }

    private fun pending(c: Context): PendingIntent = PendingIntent.getBroadcast(
        c, 31, Intent(c, ReminderReceiver::class.java),
        PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
    )

    fun set(c: Context, json: String) {
        sp(c).edit().putString("list", json).apply()
        schedule(c)
    }

    /** Henüz gösterilmemiş en yakın hatırlatma için alarm kurar. */
    fun schedule(c: Context) {
        val am = c.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val pi = pending(c)
        try { am.cancel(pi) } catch (_: Exception) {}
        val now = System.currentTimeMillis()
        val shown = sp(c).getLong("shown", 0L)
        var next = Long.MAX_VALUE
        val arr = list(c)
        for (i in 0 until arr.length()) {
            val o = arr.optJSONObject(i) ?: continue
            val t = o.optLong("t", 0L)
            if (t > shown && t + LATE_MS > now && t < next) next = t
        }
        if (next == Long.MAX_VALUE) return
        val at = if (next < now + 5000L) now + 5000L else next
        try {
            am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pi)
        } catch (_: Exception) {}
    }

    /** Zamanı gelmiş hatırlatmayı gösterir, sonra sıradakini kurar. */
    fun fire(c: Context) {
        val now = System.currentTimeMillis()
        val shown = sp(c).getLong("shown", 0L)
        var bestT = 0L
        var title = ""
        var text = ""
        val arr = list(c)
        for (i in 0 until arr.length()) {
            val o = arr.optJSONObject(i) ?: continue
            val t = o.optLong("t", 0L)
            if (t > shown && t <= now + 60000L && t > bestT) {
                bestT = t
                title = o.optString("title", "NSapp")
                text = o.optString("text", "")
            }
        }
        if (bestT > 0L) {
            sp(c).edit().putLong("shown", bestT).apply()
            if (bestT + LATE_MS > now) show(c, title, text)
        }
        schedule(c)
    }

    private fun show(c: Context, title: String, text: String) {
        val nm = c.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        if (Build.VERSION.SDK_INT >= 26) {
            val ch = NotificationChannel(CH, "Vardiya hatırlatma", NotificationManager.IMPORTANCE_HIGH)
            nm.createNotificationChannel(ch)
        }
        val pi = PendingIntent.getActivity(
            c, 0, Intent(c, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val b = if (Build.VERSION.SDK_INT >= 26) Notification.Builder(c, CH)
        else @Suppress("DEPRECATION") Notification.Builder(c)
        val n = b.setContentTitle(title)
            .setContentText(text)
            .setStyle(Notification.BigTextStyle().bigText(text))
            .setSmallIcon(R.drawable.ic_stat)
            .setAutoCancel(true)
            .setContentIntent(pi)
            .build()
        try { nm.notify(NID, n) } catch (_: Exception) {}
    }
}

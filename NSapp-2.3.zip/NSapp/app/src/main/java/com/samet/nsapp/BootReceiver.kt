package com.samet.nsapp

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, intent: Intent) {
        val a = intent.action ?: return
        if (a == Intent.ACTION_BOOT_COMPLETED || a == Intent.ACTION_MY_PACKAGE_REPLACED) {
            try { Reminder.schedule(c) } catch (_: Exception) {}
            if (Store.isTracking(c) && Store.factory(c) != null) {
                try { TrackerService.start(c) } catch (_: Exception) {}
            }
        }
    }
}

package com.samet.nsapp

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.location.Location
import android.location.LocationListener
import android.location.LocationManager
import android.os.Build
import android.os.Bundle
import android.os.IBinder
import android.os.Looper
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** Birkaç dakikada bir konum alır; fabrika alanına giriş/çıkışı kaydeder. */
class TrackerService : Service(), LocationListener {

    companion object {
        const val CH = "ns_takip"
        const val NID = 7
        const val INTERVAL_MS = 2 * 60 * 1000L

        fun start(c: Context) {
            val i = Intent(c, TrackerService::class.java)
            if (Build.VERSION.SDK_INT >= 26) c.startForegroundService(i) else c.startService(i)
        }

        fun stop(c: Context) {
            c.stopService(Intent(c, TrackerService::class.java))
        }
    }

    private var lm: LocationManager? = null
    private var outCount = 0
    private var lastOutCandidate = 0L

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        makeChannel()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val n = buildNotif(statusText())
        try {
            if (Build.VERSION.SDK_INT >= 29) {
                startForeground(NID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_LOCATION)
            } else {
                startForeground(NID, n)
            }
        } catch (e: Exception) {
            stopSelf()
            return START_NOT_STICKY
        }
        startUpdates()
        return START_STICKY
    }

    private fun startUpdates() {
        val m = getSystemService(Context.LOCATION_SERVICE) as LocationManager
        lm = m
        try { m.removeUpdates(this) } catch (_: Exception) {}
        try {
            val providers = mutableListOf<String>()
            if (Build.VERSION.SDK_INT >= 31 && m.allProviders.contains(LocationManager.FUSED_PROVIDER)) {
                providers.add(LocationManager.FUSED_PROVIDER)
            } else {
                if (m.allProviders.contains(LocationManager.NETWORK_PROVIDER)) providers.add(LocationManager.NETWORK_PROVIDER)
                if (m.allProviders.contains(LocationManager.GPS_PROVIDER)) providers.add(LocationManager.GPS_PROVIDER)
            }
            for (p in providers) {
                m.requestLocationUpdates(p, INTERVAL_MS, 0f, this, Looper.getMainLooper())
            }
        } catch (e: SecurityException) {
            stopSelf()
        }
    }

    override fun onLocationChanged(loc: Location) {
        val f = Store.factory(this) ?: return
        if (loc.hasAccuracy() && loc.accuracy > 600f) return
        val res = FloatArray(1)
        Location.distanceBetween(loc.latitude, loc.longitude, f.getDouble("lat"), f.getDouble("lon"), res)
        val dist = res[0]
        val r = f.getInt("radius").toFloat()
        val now = System.currentTimeMillis()
        Store.setLastFix(this, "${fmt(now)} · fabrikaya ${dist.toInt()} m · doğruluk ±${loc.accuracy.toInt()} m")
        if (dist <= r) {
            outCount = 0
            Store.setInside(this, true, now)
        } else if (dist > r * 1.4f) {
            // Çıkış için art arda 2 ölçüm iste (konum sıçramalarına karşı)
            if (outCount == 0) lastOutCandidate = now
            outCount++
            if (!Store.isInside(this) || outCount >= 2) {
                Store.setInside(this, false, lastOutCandidate)
            }
        }
        updateNotif()
    }

    @Deprecated("Deprecated in Java")
    override fun onStatusChanged(provider: String?, status: Int, extras: Bundle?) {}
    override fun onProviderEnabled(provider: String) {}
    override fun onProviderDisabled(provider: String) {}

    override fun onDestroy() {
        try { lm?.removeUpdates(this) } catch (_: Exception) {}
        super.onDestroy()
    }

    private fun statusText(): String {
        if (Store.factory(this) == null) return "Fabrika konumu ayarlanmadı"
        return if (Store.isInside(this)) "Fabrikadasın, süre kaydediliyor" else "Mesai takibi açık"
    }

    private fun updateNotif() {
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        try { nm.notify(NID, buildNotif(statusText())) } catch (_: Exception) {}
    }

    private fun fmt(t: Long) = SimpleDateFormat("HH:mm", Locale("tr")).format(Date(t))

    private fun makeChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            val ch = NotificationChannel(CH, "Mesai takibi", NotificationManager.IMPORTANCE_LOW)
            ch.setShowBadge(false)
            nm.createNotificationChannel(ch)
        }
    }

    private fun buildNotif(text: String): Notification {
        val pi = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val b = if (Build.VERSION.SDK_INT >= 26) Notification.Builder(this, CH)
        else @Suppress("DEPRECATION") Notification.Builder(this)
        return b.setContentTitle("NSapp")
            .setContentText(text)
            .setSmallIcon(R.drawable.ic_stat)
            .setOngoing(true)
            .setContentIntent(pi)
            .build()
    }
}

package com.samet.nsapp

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

/** Konum takibi verileri: fabrika konumu, içeride mi, giriş/çıkış olayları. */
object Store {
    private const val P = "ns_track"

    private fun sp(c: Context) = c.getSharedPreferences(P, Context.MODE_PRIVATE)

    fun factory(c: Context): JSONObject? {
        val s = sp(c)
        if (!s.contains("lat")) return null
        return JSONObject()
            .put("lat", s.getString("lat", "0")!!.toDouble())
            .put("lon", s.getString("lon", "0")!!.toDouble())
            .put("radius", s.getInt("radius", 250))
    }

    fun setFactory(c: Context, lat: Double, lon: Double, radius: Int) {
        sp(c).edit().putString("lat", lat.toString()).putString("lon", lon.toString())
            .putInt("radius", radius).remove("inside").apply()
    }

    fun isTracking(c: Context) = sp(c).getBoolean("tracking", false)
    fun setTracking(c: Context, v: Boolean) = sp(c).edit().putBoolean("tracking", v).apply()

    fun isInside(c: Context) = sp(c).getBoolean("inside", false)

    fun lastFix(c: Context): String = sp(c).getString("lastFix", "") ?: ""
    fun setLastFix(c: Context, s: String) = sp(c).edit().putString("lastFix", s).apply()

    fun events(c: Context): JSONArray =
        try { JSONArray(sp(c).getString("events", "[]")) } catch (e: Exception) { JSONArray() }

    /** Durum değiştiyse olay ekler. */
    @Synchronized
    fun setInside(c: Context, inside: Boolean, time: Long) {
        val s = sp(c)
        val known = s.contains("inside")
        if (known && s.getBoolean("inside", false) == inside) return
        if (!known && !inside) {
            // İlk ölçüm dışarıdaysa olay yazmaya gerek yok
            s.edit().putBoolean("inside", false).apply()
            return
        }
        val arr = events(c)
        arr.put(JSONObject().put("t", time).put("type", if (inside) "in" else "out"))
        val trimmed = JSONArray()
        val start = if (arr.length() > 3000) arr.length() - 3000 else 0
        for (i in start until arr.length()) trimmed.put(arr.get(i))
        s.edit().putBoolean("inside", inside).putString("events", trimmed.toString()).apply()
    }

    fun setEvents(c: Context, json: String) {
        sp(c).edit().putString("events", json).apply()
    }
}

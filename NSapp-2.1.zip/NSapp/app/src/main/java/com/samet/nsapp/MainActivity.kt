package com.samet.nsapp

import android.Manifest
import android.annotation.SuppressLint
import android.app.Activity
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.location.Location
import android.location.LocationListener
import android.location.LocationManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.webkit.JavascriptInterface
import android.webkit.ValueCallback
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import org.json.JSONObject

class MainActivity : Activity() {

    private lateinit var web: WebView
    private var fileCb: ValueCallback<Array<Uri>>? = null
    private val main = Handler(Looper.getMainLooper())

    companion object {
        const val REQ_LOC = 11
        const val REQ_BG = 12
        const val REQ_NOTIF = 13
        const val REQ_FILE = 21
    }

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.parseColor("#14161f")
        window.navigationBarColor = Color.parseColor("#14161f")
        web = WebView(this)
        web.setBackgroundColor(Color.parseColor("#14161f"))
        setContentView(web)
        val s = web.settings
        s.javaScriptEnabled = true
        s.domStorageEnabled = true
        s.allowFileAccess = true
        web.webViewClient = WebViewClient()
        web.webChromeClient = object : WebChromeClient() {
            override fun onShowFileChooser(
                view: WebView?, cb: ValueCallback<Array<Uri>>?, params: FileChooserParams?
            ): Boolean {
                fileCb?.onReceiveValue(null)
                fileCb = cb
                val i = Intent(Intent.ACTION_GET_CONTENT).addCategory(Intent.CATEGORY_OPENABLE).setType("*/*")
                return try {
                    startActivityForResult(Intent.createChooser(i, "Yedek dosyası seç"), REQ_FILE)
                    true
                } catch (e: Exception) {
                    fileCb = null
                    false
                }
            }
        }
        web.addJavascriptInterface(Bridge(), "NS")
        web.loadUrl("file:///android_asset/index.html")
    }

    override fun onResume() {
        super.onResume()
        js("window.onNative && onNative('resume')")
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        web.evaluateJavascript("window.nsBack ? nsBack() : false") { r ->
            if (r != "true") {
                @Suppress("DEPRECATION")
                super.onBackPressed()
            }
        }
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        @Suppress("DEPRECATION")
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == REQ_FILE) {
            val uri = data?.data
            fileCb?.onReceiveValue(if (resultCode == RESULT_OK && uri != null) arrayOf(uri) else null)
            fileCb = null
        }
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        js("window.onNative && onNative('perm')")
    }

    private fun js(code: String) {
        main.post { if (::web.isInitialized) web.evaluateJavascript(code, null) }
    }

    private fun has(p: String) = checkSelfPermission(p) == PackageManager.PERMISSION_GRANTED

    private fun hasFine() = has(Manifest.permission.ACCESS_FINE_LOCATION) || has(Manifest.permission.ACCESS_COARSE_LOCATION)

    private fun hasBg() = if (Build.VERSION.SDK_INT >= 29) has(Manifest.permission.ACCESS_BACKGROUND_LOCATION) else hasFine()

    private fun hasNotif() = if (Build.VERSION.SDK_INT >= 33) has(Manifest.permission.POST_NOTIFICATIONS) else true

    /** Tek seferlik, mümkün olan en iyi konumu alır (en fazla 25 sn). */
    private fun oneShotLocation(cb: (Location?) -> Unit) {
        val lm = getSystemService(Context.LOCATION_SERVICE) as LocationManager
        var best: Location? = null
        var done = false
        val listeners = mutableListOf<LocationListener>()
        fun finish() {
            if (done) return
            done = true
            for (l in listeners) try { lm.removeUpdates(l) } catch (_: Exception) {}
            cb(best)
        }
        val l = object : LocationListener {
            override fun onLocationChanged(loc: Location) {
                if (best == null || loc.accuracy < best!!.accuracy) best = loc
                if (loc.accuracy <= 30f) finish()
            }
            @Deprecated("Deprecated in Java")
            override fun onStatusChanged(provider: String?, status: Int, extras: Bundle?) {}
            override fun onProviderEnabled(provider: String) {}
            override fun onProviderDisabled(provider: String) {}
        }
        listeners.add(l)
        try {
            for (p in listOf(LocationManager.GPS_PROVIDER, LocationManager.NETWORK_PROVIDER)) {
                if (lm.allProviders.contains(p) && lm.isProviderEnabled(p)) {
                    lm.requestLocationUpdates(p, 1000L, 0f, l, Looper.getMainLooper())
                }
            }
        } catch (e: SecurityException) {
            finish()
            return
        }
        main.postDelayed({ finish() }, 25000)
    }

    inner class Bridge {
        @JavascriptInterface
        fun isNative(): Boolean = true

        @JavascriptInterface
        fun getTrack(): String {
            val c = this@MainActivity
            val o = JSONObject()
            o.put("factory", Store.factory(c) ?: JSONObject.NULL)
            o.put("tracking", Store.isTracking(c))
            o.put("inside", Store.isInside(c))
            o.put("lastFix", Store.lastFix(c))
            o.put("events", Store.events(c))
            o.put("perms", JSONObject().put("loc", hasFine()).put("bg", hasBg()).put("notif", hasNotif()))
            return o.toString()
        }

        @JavascriptInterface
        fun requestLocation() {
            main.post {
                requestPermissions(arrayOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION), REQ_LOC)
            }
        }

        @JavascriptInterface
        fun requestBackground() {
            main.post {
                if (Build.VERSION.SDK_INT >= 29) {
                    requestPermissions(arrayOf(Manifest.permission.ACCESS_BACKGROUND_LOCATION), REQ_BG)
                }
            }
        }

        @JavascriptInterface
        fun requestNotif() {
            main.post {
                if (Build.VERSION.SDK_INT >= 33) {
                    requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), REQ_NOTIF)
                }
            }
        }

        @JavascriptInterface
        fun openAppSettings() {
            main.post {
                val i = Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$packageName"))
                startActivity(i)
            }
        }

        @JavascriptInterface
        fun saveFactoryHere(radius: Int) {
            main.post {
                if (!hasFine()) {
                    js("onNative('factory', null)")
                    return@post
                }
                oneShotLocation { loc ->
                    if (loc == null) {
                        js("onNative('factory', null)")
                    } else {
                        Store.setFactory(this@MainActivity, loc.latitude, loc.longitude, radius)
                        val o = JSONObject().put("lat", loc.latitude).put("lon", loc.longitude).put("acc", loc.accuracy.toDouble())
                        js("onNative('factory', $o)")
                        if (Store.isTracking(this@MainActivity)) TrackerService.start(this@MainActivity)
                    }
                }
            }
        }

        @JavascriptInterface
        fun setRadius(radius: Int) {
            val f = Store.factory(this@MainActivity) ?: return
            Store.setFactory(this@MainActivity, f.getDouble("lat"), f.getDouble("lon"), radius)
        }

        @JavascriptInterface
        fun startTracking(): Boolean {
            val c = this@MainActivity
            if (!hasFine() || Store.factory(c) == null) return false
            Store.setTracking(c, true)
            main.post { try { TrackerService.start(c) } catch (_: Exception) {} }
            return true
        }

        @JavascriptInterface
        fun stopTracking() {
            val c = this@MainActivity
            Store.setTracking(c, false)
            main.post { TrackerService.stop(c) }
        }

        @JavascriptInterface
        fun setEvents(json: String) {
            Store.setEvents(this@MainActivity, json)
        }

        @JavascriptInterface
        fun share(text: String, title: String) {
            main.post {
                val i = Intent(Intent.ACTION_SEND).setType("text/plain")
                    .putExtra(Intent.EXTRA_SUBJECT, title)
                    .putExtra(Intent.EXTRA_TEXT, text)
                startActivity(Intent.createChooser(i, title))
            }
        }
    }
}

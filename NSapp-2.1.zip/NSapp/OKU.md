# NSapp 2.0

Vardiya takvimi + bordroya göre maaş tahmini + konumla otomatik mesai.
Arayüz `app/src/main/assets/index.html` içinde, konum takibi Kotlin tarafında.

## APK alma – GitHub (telefondan)
1. Private bir repo aç, bu zip dosyasını olduğu gibi (açmadan) yükle.
2. Add file > Create new file: adı `.github/workflows/apk.yml`, içine apk.yml metnini yapıştır, Commit.
3. Actions sekmesinde derleme bitince repo ana sayfasındaki Releases'ten NSapp.apk'yı indir.

## APK alma – Android Studio
Open > NSapp klasörü > Build > Build APK(s) > app/build/outputs/apk/debug/app-debug.apk

## Not
İmza anahtarı (`app/nsapp.keystore`) projenin içinde. Aynı kaldıkça yeni sürüm
eskisinin üstüne kurulur, veriler silinmez. Paket adı `com.samet.nsapp`.
